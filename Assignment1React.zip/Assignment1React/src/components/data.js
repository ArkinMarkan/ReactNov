export const arr = [
    {
        id: 1,
        name: 'Arkin',
        email: 'Arkin@example.com',
        age: 21,
        },
        {
        id: 2,
        name: 'Paras',
        email: 'paras@example.com',
        age: 18,
        },
        {
        id: 3,
        name: 'Neeraj',
        email: 'neeraj@example.com',
        age: 26,
        },
        {
        id: 4,
        name: 'Karan',
        email: 'karan@example.com',
        age: 28,
        },
]