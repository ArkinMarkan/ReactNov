import React, { useEffect, useState } from 'react';
import ButtonCounter from './ButtonCounter';

const App = () => {

  const [totalCount,setTotalCount] = useState(0);
  const [reset,setReset] = useState(false);

  useEffect(()=>{
    console.log('reset');
    setReset(false)
    setTotalCount(0)
  },[reset])

  const handleClick = () =>{
    setTotalCount(totalCount+1)
  }
  
  const array=[0,1,2];

  return (
    <div className='container mt-5'>
      <div className='card-deck'>
        {array.map((id)=>
        <div className='row mb-3'>
          {[1,2,3].map(num=>
            <ButtonCounter bn={id*3 + num} reset={reset} handleClick={handleClick}/>
          )}
        </div>
          
        )}
        <div className='text-center'>
          <h4>Total Count: {totalCount}</h4>
          <br/>
          <button className='btn btn-danger' onClick={()=>setReset(true)}>Reset</button>
        </div>
      </div>
    </div>
  );
};

export default App;